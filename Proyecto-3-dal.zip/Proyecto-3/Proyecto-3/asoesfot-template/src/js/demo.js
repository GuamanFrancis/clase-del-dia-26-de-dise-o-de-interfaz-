alert("Hola....")



//acceder a los elementos

const titulo = document.querySelector('h1')


titulo.textContent= "Más Informacion...";
titulo.style.color= 'blue'

//crear elementos 

const nuevoParrafo = document.createElement('p');
nuevoParrafo.textContent= "Acceder a beneficios"
document.body.appendChild(nuevoParrafo)
titulo.insertAdjacentElement('afterend',nuevoParrafo)


//Agregar interactividad 
const boton = document.createElement('button')
boton.textContent='Login'
nuevoParrafo.insertAdjacentElement('afterend',boton)

boton.addEventListener('click',()=>prompt ("Hola, Ingresa tus datos"))


//eliminar elementos

const tituloPrincipal = document.getElementsByClassName('header__barra');
while (tituloPrincipal.length>0) {

    tituloPrincipal[0].remove()
    
}

